const C = 'kanji-otoshi-65a7184554', CORE = ["index.html", "matter.min.js", "dict.txt", "manifest.webmanifest", "icons/icon-512-maskable.png", "icons/icon-192.png", "icons/icon-512.png", "fonts/fonts.css"];
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.addAll(['./', ...CORE])).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => { if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(caches.match(e.request, {ignoreSearch:true}).then(r => r || fetch(e.request).then(res => { if (res.ok){ const cp = res.clone(); caches.open(C).then(c => c.put(e.request, cp)); } return res; }))); });
